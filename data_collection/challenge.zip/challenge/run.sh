pkill -9 flask # kill if the flask running
export FLASK_APP=run.py 
flask run